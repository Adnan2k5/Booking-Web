import React from 'react'
import { Star } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../../components/ui/card"
import { Button } from "../../components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "../../components/ui/avatar"
import { Badge } from "../../components/ui/badge"

import { Separator } from "../../components/ui/separator"
import { useTranslation } from 'react-i18next'
import InstructorLayout from './InstructorLayout'



export const InstructorProfile = () => {
    const mockData = {
        instructor: {
            id: 1,
            name: "Alex Johnson",
            email: "alex.johnson@example.com",
            specialty: "Mountain Hiking",
            experience: "8 years",
            rating: 4.9,
            img: "/placeholder.svg?height=400&width=300",
            bio: "Certified mountain guide with expertise in alpine terrain and wilderness survival.",
            totalRevenue: 24580,
            totalBookings: 156,
            upcomingSessions: 12,
            completedSessions: 144,
            revenueIncrease: 12.5,
            bookingIncrease: 8.2,
            languages: ["English", "Spanish", "French"],
            certificates: ["Mountain Guide Certification", "First Aid Certification", "Avalanche Safety"],
        },
        upcomingBookings: [
            {
                id: "B-1234",
                adventure: "Mountain Climbing",
                location: "Alpine Heights",
                date: "2025-04-20",
                time: "09:00 AM",
                duration: "6 hours",
                participants: 4,
                amount: 450,
                status: "confirmed",
            },
            {
                id: "B-1235",
                adventure: "Wilderness Survival",
                location: "Evergreen Forest",
                date: "2025-04-22",
                time: "10:00 AM",
                duration: "8 hours",
                participants: 6,
                amount: 720,
                status: "confirmed",
            },
            {
                id: "B-1236",
                adventure: "Rock Climbing",
                location: "Granite Peaks",
                date: "2025-04-25",
                time: "08:30 AM",
                duration: "5 hours",
                participants: 3,
                amount: 375,
                status: "pending",
            },
        ],
        recentBookings: [
            {
                id: "B-1230",
                adventure: "Mountain Climbing",
                location: "Alpine Heights",
                date: "2025-04-10",
                participants: 5,
                amount: 550,
                status: "completed",
                rating: 5,
            },
            {
                id: "B-1231",
                adventure: "Wilderness Survival",
                location: "Evergreen Forest",
                date: "2025-04-08",
                participants: 4,
                amount: 480,
                status: "completed",
                rating: 4.8,
            },
            {
                id: "B-1232",
                adventure: "Rock Climbing",
                location: "Granite Peaks",
                date: "2025-04-05",
                participants: 3,
                amount: 375,
                status: "completed",
                rating: 5,
            },
            {
                id: "B-1233",
                adventure: "Alpine Hiking",
                location: "Mountain Range",
                date: "2025-04-02",
                participants: 6,
                amount: 600,
                status: "completed",
                rating: 4.7,
            },
        ],
        monthlyRevenue: [
            { month: "Jan", revenue: 1800 },
            { month: "Feb", revenue: 2200 },
            { month: "Mar", revenue: 2500 },
            { month: "Apr", revenue: 2800 },
            { month: "May", revenue: 3200 },
            { month: "Jun", revenue: 3500 },
            { month: "Jul", revenue: 3800 },
            { month: "Aug", revenue: 3600 },
            { month: "Sep", revenue: 3400 },
            { month: "Oct", revenue: 3100 },
            { month: "Nov", revenue: 2800 },
            { month: "Dec", revenue: 2500 },
        ],
        adventureTypes: [
            { name: "Mountain Climbing", bookings: 45, revenue: 5400 },
            { name: "Wilderness Survival", bookings: 38, revenue: 4560 },
            { name: "Rock Climbing", bookings: 32, revenue: 3840 },
            { name: "Alpine Hiking", bookings: 41, revenue: 4920 },
        ],
        sessions: [
            {
                id: "S-1001",
                title: "Mountain Climbing Basics",
                adventure: "Mountain Climbing",
                location: "Alpine Heights",
                price: 120,
                duration: "6 hours",
                capacity: 8,
                description: "Learn the fundamentals of mountain climbing in a safe environment with professional guidance.",
                upcoming: [
                    { date: "2025-04-20", time: "09:00 AM", booked: 4, available: 4 },
                    { date: "2025-04-27", time: "09:00 AM", booked: 6, available: 2 },
                    { date: "2025-05-04", time: "09:00 AM", booked: 2, available: 6 },
                ],
            },
            {
                id: "S-1002",
                title: "Wilderness Survival Workshop",
                adventure: "Wilderness Survival",
                location: "Evergreen Forest",
                price: 150,
                duration: "8 hours",
                capacity: 10,
                description:
                    "Master essential survival skills in the wilderness, including shelter building, fire making, and navigation.",
                upcoming: [
                    { date: "2025-04-22", time: "10:00 AM", booked: 6, available: 4 },
                    { date: "2025-04-29", time: "10:00 AM", booked: 8, available: 2 },
                    { date: "2025-05-06", time: "10:00 AM", booked: 3, available: 7 },
                ],
            },
            {
                id: "S-1003",
                title: "Rock Climbing for Beginners",
                adventure: "Rock Climbing",
                location: "Granite Peaks",
                price: 125,
                duration: "5 hours",
                capacity: 6,
                description: "Introduction to rock climbing techniques, safety procedures, and equipment for beginners.",
                upcoming: [
                    { date: "2025-04-25", time: "08:30 AM", booked: 3, available: 3 },
                    { date: "2025-05-02", time: "08:30 AM", booked: 5, available: 1 },
                    { date: "2025-05-09", time: "08:30 AM", booked: 2, available: 4 },
                ],
            },
        ],
    }

    const adventureTypes = [
        "Mountain Climbing",
        "Wilderness Survival",
        "Rock Climbing",
        "Alpine Hiking",
        "Kayaking",
        "Scuba Diving",
        "Paragliding",
        "Skiing",
    ]

    const locations = [
        "Alpine Heights",
        "Evergreen Forest",
        "Granite Peaks",
        "Mountain Range",
        "Crystal Lake",
        "Coastal Cliffs",
        "Desert Canyon",
        "Snowy Summit",
    ]

    // Animation variants
    const fadeIn = {
        hidden: { opacity: 0, y: 20 },
        visible: {
            opacity: 1,
            y: 0,
            transition: { duration: 0.4 },
        },
    }

    const staggerContainer = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.1,
            },
        },
    }

    const { t } = useTranslation();
    return (
        <InstructorLayout>
            <div value="profile" className="space-y-4">
                <Card>
                    <CardHeader>
                        <CardTitle>{t("instructor.profileInformation")}</CardTitle>
                        <CardDescription>{t("instructor.manageProfileDescription")}</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="flex flex-col md:flex-row gap-8">
                            <div className="md:w-1/3 flex flex-col items-center">
                                <Avatar className="h-32 w-32 mb-4">
                                    <AvatarImage src={mockData.instructor.img || "/placeholder.svg"} alt={mockData.instructor.name} />
                                    <AvatarFallback>{mockData.instructor.name.charAt(0)}</AvatarFallback>
                                </Avatar>
                                <div className="text-center">
                                    <h3 className="font-semibold text-xl">{mockData.instructor.name}</h3>
                                    <p className="text-muted-foreground">{mockData.instructor.specialty}</p>
                                    <div className="flex items-center justify-center mt-2">
                                        <Star className="h-4 w-4 text-yellow-500 fill-current" />
                                        <span className="ml-1 font-medium">{mockData.instructor.rating}</span>
                                    </div>
                                    <p className="text-sm text-muted-foreground mt-1">{mockData.instructor.experience}</p>
                                </div>
                                <Button variant="outline" className="mt-4 w-full">
                                    {t("instructor.changePhoto")}
                                </Button>
                            </div>

                            <div className="md:w-2/3">
                                <div className="space-y-4">
                                    <div>
                                        <h4 className="font-medium mb-2">{t("instructor.bio")}</h4>
                                        <p className="text-muted-foreground">{mockData.instructor.bio}</p>
                                    </div>

                                    <Separator />

                                    <div>
                                        <h4 className="font-medium mb-2">{t("instructor.bio")}</h4>
                                        <p className="text-muted-foreground">{mockData.instructor.bio}</p>
                                    </div>

                                    <Separator />

                                    <div>
                                        <h4 className="font-medium mb-2">{t("instructor.languages")}</h4>
                                        <div className="flex flex-wrap gap-2">
                                            {mockData.instructor.languages.map((language, index) => (
                                                <Badge key={index} variant="outline">
                                                    {language}
                                                </Badge>
                                            ))}
                                        </div>
                                    </div>

                                    <Separator />

                                    <div>
                                        <h4 className="font-medium mb-2">{t("instructor.certificates")}</h4>
                                        <div className="space-y-2">
                                            {mockData.instructor.certificates.map((certificate, index) => (
                                                <div key={index} className="flex items-center gap-2">
                                                    <div className="h-2 w-2 rounded-full bg-green-500"></div>
                                                    <span>{certificate}</span>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>

                                <div className="mt-6 flex justify-end gap-2">
                                    <Button variant="outline">{t("instructor.editProfile")}</Button>
                                    <Button>{t("instructor.saveChanges")}</Button>
                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </InstructorLayout>
    )
}
