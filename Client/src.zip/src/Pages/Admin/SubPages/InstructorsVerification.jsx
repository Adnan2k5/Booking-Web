import React from 'react'

export const InstructorsVerification = () => {
    return (
        <div>InstructorsVerification</div>
    )
}
