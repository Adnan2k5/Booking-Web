"use client"

import { useEffect, useState, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { format } from "date-fns"
import { useLocation, useNavigate } from "react-router-dom"
import {
  ArrowLeft,
  ChevronRight,
} from "lucide-react"
import { Badge } from "../components/ui/badge"
import { fetchAllAdventures } from "../Api/adventure.api"
import { useAuth } from "./AuthProvider.jsx"
import { Loader } from "../components/Loader.jsx"
import { SearchFilterBar } from "../components/BrowsingPage/SearchFilterBar"
import { CategorySelector } from "../components/BrowsingPage/CategorySelector"
import { AdventureCard } from "../components/BrowsingPage/AdventureCard"
import { AdventureCardSkeleton } from "../components/BrowsingPage/AdventureCardSkeleton"
import { NoResults } from "../components/BrowsingPage/NoResults"

export default function BrowsingPage() {
  const location = useLocation()
  const navigate = useNavigate()
  const query = new URLSearchParams(location?.search)
  const [isLoading, setIsLoading] = useState(true)
  const [adventure, setAdventure] = useState(query.get("adventure")?.toLowerCase() || "")
  const [loc, setLoc] = useState(query.get("location")?.toLowerCase() || "")
  const [date, setDate] = useState(() => {
    const queryDate = query.get("date")
    return queryDate ? new Date(queryDate) : undefined
  })
  const [activeCategory, setActiveCategory] = useState("all")
  const [showScrollIndicator, setShowScrollIndicator] = useState(true)
  const categoriesRef = useRef(null)
  const [adventures, setAdventures] = useState([])

  const categories = [
    { id: "all", name: "All" },
    { id: "hiking", name: "Hiking" },
    { id: "water", name: "Water Sports" },
    { id: "camping", name: "Camping" },
    { id: "climbing", name: "Climbing" },
    { id: "cycling", name: "Cycling" },
  ]

  const wrapperStyle = {
    width: 300,
    border: `1px solid #e2e8f0`,
    borderRadius: "0.375rem",
  }

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1500)
    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    setIsLoading(true)
    fetchAllAdventures()
      .then((data) => {
        console.log(data.data.data)
        setAdventures(data.data.data)
      })
      .catch((err) => {
        setAdventures([])
      })
      .finally(() => setIsLoading(false))
  }, [])

  const { user, loading } = useAuth()



  useEffect(() => {
    const handleScroll = () => {
      if (categoriesRef.current) {
        const { scrollWidth, scrollLeft, clientWidth } = categoriesRef.current
        setShowScrollIndicator(scrollWidth > clientWidth && scrollLeft < scrollWidth - clientWidth - 20)
      }
    }

    const categoryContainer = categoriesRef.current
    if (categoryContainer) {
      categoryContainer.addEventListener("scroll", handleScroll)
      handleScroll()
    }

    return () => {
      if (categoryContainer) {
        categoryContainer.removeEventListener("scroll", handleScroll)
      }
    }
  }, [])

  const filteredAdventures = adventures.filter((adventureItem) => {
    const matchesAdventure = !adventure || adventure === "all" || adventureItem.name.toLowerCase().includes(adventure)
    const matchesLoc = !loc || loc === "all" || adventureItem.location.toLowerCase().includes(loc)

    const matchesCategory =
      activeCategory === "all" || (adventureItem.category && adventureItem.category === activeCategory)

    let matchesDate = true
    if (date && date instanceof Date && !isNaN(date)) {
      const advDate = new Date(adventureItem.date)
      if (advDate instanceof Date && !isNaN(advDate)) {
        matchesDate = format(advDate, "yyyy-MM-dd") === format(date, "yyyy-MM-dd")
      }
    }

    return matchesAdventure && matchesLoc && matchesDate && matchesCategory
  })

  const onBook = (id) => {
    navigate(`/booking?id=${id}`)
  }

  const clearFilter = (type) => {
    switch (type) {
      case "adventure":
        setAdventure("")
        break
      case "location":
        setLoc("")
        break
      case "date":
        setDate(undefined)
        break
      case "all":
        setAdventure("")
        setLoc("")
        setDate(undefined)
        setActiveCategory("all")
        break
      default:
        break
    }
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100,
      },
    },
  }

  const handleDateChange = (value) => {
    if (value) {
      const selectedDate = new Date(value.format("YYYY-MM-DD"))
      setDate(selectedDate)
    } else {
      setDate(undefined)
    }
  }

  const formatDate = (dateString) => {
    try {
      const date = new Date(dateString)
      if (isNaN(date.getTime())) {
        return "Invalid date"
      }
      return format(date, "MMM dd, yyyy")
    } catch (error) {
      console.error("Date formatting error:", error)
      return "Invalid date"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 sm:p-6 relative overflow-hidden">
      <div className="absolute inset-0 z-0 overflow-hidden">
        <div className="bubble absolute top-[10%] left-[15%] w-64 h-64 bg-blue-200 rounded-full opacity-20 blur-[80px] transition-transform duration-1000 ease-in-out"></div>
        <div className="bubble absolute top-[40%] left-[60%] w-96 h-96 bg-purple-200 rounded-full opacity-20 blur-[100px] transition-transform duration-1000 ease-in-out"></div>
        <div className="bubble absolute bottom-[10%] right-[20%] w-72 h-72 bg-cyan-200 rounded-full opacity-20 blur-[90px] transition-transform duration-1000 ease-in-out"></div>
      </div>

      <div className="relative z-10 mx-auto max-w-7xl">
        <div className="flex justify-between items-center mb-6">
          <motion.button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 p-2 rounded-full bg-white/80 backdrop-blur-sm shadow-sm hover:bg-white transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            aria-label="Go back"
          >
            <ArrowLeft size={18} />
            <span className="text-sm font-medium">Back</span>
          </motion.button>

          <motion.div
            className="flex items-center gap-3"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            {loading ? (
              <Loader />
            ) : (
              <motion.div
                className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center rounded-full text-white font-medium shadow-md"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {user?.user?.email.charAt(0).toUpperCase()}
              </motion.div>
            )}
          </motion.div>
        </div>

        <motion.div
          className="mb-8 text-center"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            Discover Adventures
          </h1>
          <p className="text-gray-600 mt-2">Find your next unforgettable experience</p>
        </motion.div>

        <motion.div
          className="bg-white/90 backdrop-blur-md rounded-2xl shadow-lg p-4 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <SearchFilterBar
            adventure={adventure}
            setAdventure={setAdventure}
            loc={loc}
            setLoc={setLoc}
            date={date}
            setDate={setDate}
            clearFilter={clearFilter}
            handleDateChange={handleDateChange}
            wrapperStyle={wrapperStyle}
          />
        </motion.div>

        <CategorySelector
          categories={categories}
          activeCategory={activeCategory}
          setActiveCategory={setActiveCategory}
          categoriesRef={categoriesRef}
          showScrollIndicator={showScrollIndicator}
          ChevronRight={ChevronRight}
        />

        <motion.div
          className="flex items-center gap-2 mb-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <h2 className="text-xl font-semibold text-gray-800">Results</h2>
          <Badge variant="outline" className="text-gray-500 bg-white/80 backdrop-blur-sm">
            {filteredAdventures.length} adventures
          </Badge>
        </motion.div>

        <AnimatePresence>
          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {isLoading
              ? Array(6)
                .fill(0)
                .map((_, index) => (
                  <motion.div
                    key={`skeleton-${index}`}
                    variants={itemVariants}
                  >
                    <AdventureCardSkeleton />
                  </motion.div>
                ))
              : filteredAdventures.map((adventure) => (
                <motion.div
                  key={adventure._id}
                  variants={itemVariants}
                  layout
                  className="h-full"
                  whileHover={{ y: -8 }}
                  transition={{ type: "spring", stiffness: 300 }}
                  onClick={() => onBook(adventure._id)}
                  style={{ cursor: "pointer" }}
                >
                  <AdventureCard adventure={adventure} formatDate={formatDate} onBook={onBook} />
                </motion.div>
              ))}
          </motion.div>
        </AnimatePresence>

        {filteredAdventures.length === 0 && !isLoading && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center py-12">
            <NoResults clearFilter={clearFilter} />
          </motion.div>
        )}
      </div>
    </div>
  )
}

