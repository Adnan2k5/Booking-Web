import React, { useEffect, useState } from 'react'
import { useAuth } from '../AuthProvider';
import { getHotelByOwnerId } from '../../Api/hotel.api.js';

export const Hotel = () => {
    const { user } = useAuth();
    const [loading, setLoading] = useState(false);
    console.log(user);
    const fetchHotel = async () => {
        setLoading(true);
        try {
            const res = await getHotelByOwnerId(user.user._id);
            console.log(res);
        } catch (error) {
            console.error("Error fetching hotel:", error);
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        fetchHotel();
    }, []);
    return (
        <div>
            hai
        </div>
    )
}
