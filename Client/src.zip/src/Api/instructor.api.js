export const fetchInstructors = async (id) => {
  const res = await axiosClient.get('/api/');
};
